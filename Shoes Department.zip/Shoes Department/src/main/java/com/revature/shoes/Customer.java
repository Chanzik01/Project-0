package com.revature.shoes;

public class Customer extends User{
    private Integer id;
    private String firstName;
    private String lastName;

    public Customer() {

    }

    public Customer(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /*
     * Retrieves id
     */
    public Integer getId() {
        return id;
    }

    /*
     * Sets id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /*
     * Retrieves first name
     */
    public String getFirstName() {
        return firstName;
    }

    /*
     * Sets first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /*
     * Retrieves last name
     */
    public String getLastName() {
        return lastName;
    }

    /*
     * Sets last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /*
     * Stores first and last name of customer as a string
     */
    public String toString() {
        return "Hello: " + this.firstName + " " + this.lastName;
    }
}
