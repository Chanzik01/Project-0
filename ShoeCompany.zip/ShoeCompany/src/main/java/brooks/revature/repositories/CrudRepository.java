package brooks.revature.repositories;

import java.util.List;

public interface CrudRepository<T> {

        // Create
        // public abstract T add(T t)

        T add(T t);

        // Read
        // public abstract T getById(Integer id)

        T getById(Integer id);



        List<T> getAll();

        // Update
        // public abstract T update(T t)

        void update(T t);

        // Delete
        // public abstract void delete(Integer id)

        void delete(Integer id);
}
