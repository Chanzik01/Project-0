package brooks.revature.services;

import brooks.revature.models.ShoeItem;
import brooks.revature.models.User;
import brooks.revature.repositories.ShoeRepo;
import brooks.revature.repositories.UserRepo;

import java.util.InputMismatchException;
import java.util.Random;

public class UserServices {

    UserRepo userRepo = new UserRepo();
    ShoeRepo shoeRepo = new ShoeRepo();

    public boolean login(String username, String password ) {

        try {

            User u = userRepo.getByUsername(username);
            u.setLoggedIn(true);


            if (u != null) {
                if(username.equals(u.getUserName()) && password.equals(u.getPassword())) {
                    return true;
                }
            }


            if (!u.getUserName().equals(username)) {
                throw new InputMismatchException("No such user exist.");
            }

            if(username.contains(" ")) {
                System.out.println("Username cannot contain spaces.");
            }

        } catch(NullPointerException e) {
            System.out.println("This user does not exist. Try entering correct credentials or create an account.");
            System.out.println();
        }

        return false;
    }

    public void accountCreation(String username, String password, String firstName, String lastName, String isEmployee) {

        try {

            if (this.containLettersOnly(firstName) && this.containLettersOnly(lastName)) {

            }
            else {
                throw new InputMismatchException("Name can only contain letters.");
            }

            User myUser = new User(username, password, firstName, lastName, isEmployee);

            myUser.setLoggedIn(true);

            this.userRepo.add(myUser);


            if(isEmployee.equals("y") || isEmployee.equals("yes")) {
                myUser.setEmployeeStatus("yes");
                System.out.println("You have created an account");
                System.out.println();
            }
            else if(isEmployee.equals("n") || isEmployee.equals("no")){
                myUser.setEmployeeStatus("no");
                System.out.println("You have created an account");
                System.out.println();
            }
            else {
                System.out.println("Please enter yes or no. Try logging in again.");
                System.out.println();
            }

        } catch(Exception e) {
            e.printStackTrace();
        }


    }


    public int displayFunds(String username) {
        User u = userRepo.getByUsername(username);
        return u.getFunds();
    }

    public void displayInventory() {
        System.out.println(this.shoeRepo.getAllShoes().toString());
        System.out.println();
    }

    public void displayInventory(String username, String password) {
        if (this.login(username, password)) {
            System.out.println(this.shoeRepo.getAllShoes().toString());
            System.out.println();
        }

    }

    public void addFunds(Integer funds, String username) {
        User u = userRepo.getByUsername(username);
        userRepo.addFunds(funds + u.getFunds(), username);
    }


    public void logout(String username, String password) {
        User u = userRepo.getByUsername(username);
        userRepo.logout(u);
    }

    public void addShoes(String brand, String name, String color, String category, Integer size, Integer price,
                         String username, String password) {
        try {
            ShoeItem myShoes = new ShoeItem(brand, name, color, category, size, price);

            //this.login(username, password);
            if(!this.login(username, password)) {
                System.out.println("Incorrect credential or create an account.");
                System.out.println();
            } else {
                this.shoeRepo.add(myShoes);
                System.out.println("Your shoes have been add!");
                System.out.println();
            }

        } catch(NullPointerException e) {
            //e.printStackTrace();
            System.out.println("Incorrect credentials or account does not exist.");
            System.out.println();
        }

    }

    /*
     * Next time break down each local variable into a getter method
     */
    public void buyShoes(String username, String password, String brand, String shoeName, String color,
                         String category, Integer size, Integer price) {

        try {
            User u = this.userRepo.getByUsername(username);
            ShoeItem s = new ShoeItem(brand, shoeName, color, category, size, price);

            this.login(username, password);
            int funds = u.getFunds();
            int shoePrice = s.getPrice();

                if(funds >= shoePrice) {
                    if(u.getEmployeeStatus().equals("yes")) {
                        u.setFunds(funds - (shoePrice / 2));

                        this.shoeRepo.buyShoes(s);

                        this.userRepo.update(u);
                    }
                    else if(u.getEmployeeStatus().equals("no")) {
                        u.setFunds(funds - shoePrice);

                        this.shoeRepo.buyShoes(s);

                        this.userRepo.update(u);
                    }

                }
                else if(u.getFunds() < s.getPrice()) {
                    if(u.getEmployeeStatus().equals("yes")) {
                        u.setFunds(u.getFunds() - (s.getPrice() / 2));

                        this.shoeRepo.buyShoes(s);

                        this.userRepo.update(u);
                    }

                }
                else {
                    System.out.println("You need more funds to purchase.");
                    System.out.println();
                }


        } catch(NullPointerException e) {
            System.out.println("No such user in database.");
            System.out.println();
        }


    }

    public boolean containLettersOnly (String name) {
        char[] chars = name.toCharArray();
        StringBuilder sb = new StringBuilder();
        boolean answer = false;
        for(char c : chars){
            if(Character.isLetter(c)){
                answer = true;
            }
        }
        return answer;
    }

    public void isEmployee(String username) {
        User u = userRepo.getByUsername(username);

        try{

            if (u.getEmployeeStatus().equals("yes")) {
                System.out.println("Discount applied.");
                System.out.println();
            }
            else {
                System.out.println("No discount applied. Employees only.");
                System.out.println();
            }
        } catch(NullPointerException e) {
            System.out.println("User is not an employee.");
            System.out.println();
        }

    }

    public void discount() {
        this.shoeRepo.discount();
    }

}
