package brooks.revature.models;

public class HomePage {
    public HomePage() {

    }

    /*
     * Displays home page
     */
    public static void displayHome() {
        System.out.println("Hello! Please sign.");
        System.out.println("1) Sign in.");
        System.out.println("2) New User? Create account here.");
        System.out.println("3) Exit");
    }

    /*
     * Checks for strings containing only letters
     */
    public String isValid(String string) {
        String a = "";
        if(! string.matches(".*[^a-z].*")) {
            a = "Your input can only contain letters.";
        }
        return a;
    }
}
